

To install unzip and execute "python setup.py install"